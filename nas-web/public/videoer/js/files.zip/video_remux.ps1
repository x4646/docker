# video_remux.ps1 -- container remux for web playback (ffmpeg -c copy, no re-encode)
#
# Takes videos whose codec the browser understands but whose container it doesn't
# (ts/flv/avi-h264/mkv-h264/mkv-vp9 ...), copies streams into an .mp4 container.
# No decode/encode happens -- this is seconds per file, lossless.
# Original file is NEVER touched. Output path for each file is given by the NAS
# response (convPath), which mirrors the source directory under a subfolder next
# to the source root -- see video-conv.js convBase() on the server side.
#
# Run:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\video_remux.ps1
#   .\video_remux.ps1 -Limit 20
#   .\video_remux.ps1 -Jobs 4
#
# NOTE: pure ASCII on purpose. Windows PowerShell 5.1 reads BOM-less UTF-8
#       scripts as ANSI (GBK on Chinese systems), which mangles non-ASCII
#       characters and can break string terminators. Do not add non-ASCII
#       text (including Chinese) directly into this script file.

param(
    [string]$Nas = 'http://192.168.0.3:3050',
    [int]$Limit  = 0,
    [int]$Jobs   = 8
)

$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$MAP = @(
    @('/share/Person',    'P:'),
    @('/share/Bak',       'B:'),
    @('/share/BAK',       'B:'),
    @('/share/Media',     'M:'),
    @('/share/Container', 'X:')
)

if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Write-Host "[STOP] ffmpeg not found in PATH"; exit 1
}
Write-Host "NAS    : $Nas"
Write-Host "Jobs   : $Jobs (remux, -c copy, no re-encode)"
Write-Host "Output : path given per-file by the NAS (mirrors source dir under a subfolder)"
Write-Host ""

$workerCode = {
    param($md5, $vpath, $convPath)

    $MAP = @(
        @('/share/Person',    'P:'),
        @('/share/Bak',       'B:'),
        @('/share/BAK',       'B:'),
        @('/share/Media',     'M:'),
        @('/share/Container', 'X:')
    )
    function ToWin($p) {
        foreach ($m in $MAP) {
            if ($p.StartsWith($m[0])) { return $m[1] + ($p.Substring($m[0].Length) -replace '/', '\') }
        }
        return $p -replace '/', '\'
    }

    $src = ToWin $vpath
    $out = ToWin $convPath

    $res = [pscustomobject]@{ md5 = $md5; ok = $false; err = '' }
    if (-not (Test-Path -LiteralPath $src)) { $res.err = 'file not found'; return $res }

    $outDir = Split-Path -Parent $out
    if (-not (Test-Path -LiteralPath $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null } catch {}
    }

    try {
        # -c copy: pure remux, no decode/encode. +faststart for web playback (moov atom at front).
        & ffmpeg -hide_banner -loglevel error -y -i "$src" -c copy -movflags +faststart -- "$out" 2>$null
        if ((Test-Path -LiteralPath $out) -and (Get-Item -LiteralPath $out).Length -gt 0) {
            $res.ok = $true
        } else {
            $res.err = 'output empty'
            Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue
        }
    } catch { $res.err = $_.Exception.Message }
    return $res
}

$pool = [RunspaceFactory]::CreateRunspacePool(1, $Jobs)
$pool.Open()

[int]$totalDone = 0
[int]$totalFail = 0
[int]$round = 0
$swAll = [Diagnostics.Stopwatch]::StartNew()

while ($true) {
    $round++
    $batch = 100
    if ($Limit -gt 0) {
        $left = $Limit - $totalDone - $totalFail
        if ($left -le 0) { break }
        if ($left -lt 100) { $batch = $left }
    }

    try {
        $resp = Invoke-RestMethod -Uri "$Nas/api/vconv/pending?mode=remux&limit=$batch" -TimeoutSec 30
    } catch {
        Write-Host "[STOP] cannot reach NAS: $($_.Exception.Message)"; break
    }
    $vids = @($resp.videos)
    if ($vids.Count -eq 0) { Write-Host "queue empty"; break }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $running = @()
    foreach ($v in $vids) {
        $ps = [PowerShell]::Create()
        $ps.RunspacePool = $pool
        $null = $ps.AddScript($workerCode).AddArgument($v.md5).AddArgument($v.path).AddArgument($v.convPath)
        $running += [pscustomobject]@{ ps = $ps; handle = $ps.BeginInvoke() }
    }

    $results = @()
    foreach ($r in $running) {
        try { $out = $r.ps.EndInvoke($r.handle); if ($out) { $results += @($out) } }
        catch { Write-Host "  [WARN] worker error: $($_.Exception.Message)" }
        $r.ps.Dispose()
    }

    $good = @($results | Where-Object { $_.ok })
    $bad  = @($results | Where-Object { -not $_.ok })

    if ($good.Count -gt 0) {
        $items = @($good | ForEach-Object { @{ md5 = $_.md5; mode = 'remux' } })
        $body = @{ items = $items } | ConvertTo-Json -Depth 5 -Compress
        try {
            Invoke-RestMethod -Uri "$Nas/api/vconv/done-batch" -Method Post -Body $body -ContentType 'application/json' -TimeoutSec 60 | Out-Null
        } catch { Write-Host "[WARN] done-batch failed: $($_.Exception.Message)" }
    }
    foreach ($b in $bad) {
        $fb = @{ md5 = $b.md5; error = $b.err } | ConvertTo-Json -Compress
        try { Invoke-RestMethod -Uri "$Nas/api/vconv/fail" -Method Post -Body $fb -ContentType 'application/json' -TimeoutSec 20 | Out-Null } catch {}
        Write-Host ("  FAIL {0}  {1}" -f $b.md5, $b.err)
    }

    $totalDone = $totalDone + $good.Count
    $totalFail = $totalFail + $bad.Count
    $sw.Stop()
    $secs = [Math]::Max(0.001, $sw.Elapsed.TotalSeconds)
    Write-Host ("round {0}: ok {1}, fail {2}, {3}s ({4}/s)  --  total ok {5} fail {6}" -f `
        $round, $good.Count, $bad.Count, [Math]::Round($secs), [Math]::Round($results.Count / $secs, 2), $totalDone, $totalFail)

    if ($Limit -gt 0 -and ($totalDone + $totalFail) -ge $Limit) { break }
}

$pool.Close()
$pool.Dispose()
$swAll.Stop()
Write-Host ""
Write-Host ("DONE: ok {0}, fail {1}, elapsed {2} min" -f $totalDone, $totalFail, [Math]::Round($swAll.Elapsed.TotalMinutes, 1))
