// video-conv.js — 网页可播版本转换(换壳/转码), 不改动原始文件
//
// 原文件永远不动(PotPlayer 用它)。转好的版本另存到 vconv/, 网页优先用这份播放。
// web_ready: 0=未处理 1=换壳完成 2=转码完成 -1=失败
//
// 挂载: try { require('./public/js/video-conv.js')(app, getDb); } catch(e) { }

module.exports = function (app, getDb) {
  var express = require('express');
  var fs = require('fs');
  var path = require('path');

  // 转换后的文件放在"每个根目录下的 转换/ 子目录", 镜像原目录结构:
  //   /share/Media/x/视频.ts        (原文件, 不动)
  //   /share/Media/转换/x/视频_换壳.mp4   (换壳)
  //   /share/Media/转换/x/视频_转码.mp4   (转码)
  // 真实路径(带 CACHEDEV 卷)与入库路径(/share/Xxx)的互转沿用 video-ext.js 的规则

  (function init() {
    var db = getDb();
    var cols = db.prepare('PRAGMA table_info(photos)').all().map(function (c) { return c.name; });
    if (cols.indexOf('web_ready') < 0) {
      db.exec('ALTER TABLE photos ADD COLUMN web_ready INTEGER DEFAULT 0');
      db.exec('CREATE INDEX IF NOT EXISTS idx_photos_web_ready ON photos(web_ready)');
      console.log('[vconv] 已添加 web_ready 字段');
    }
    console.log('[video-conv] 初始化完成 (转换文件存于各根目录下的 转换/ 子目录)');
  })();

  function toRealPath(dbPath) {
    if (dbPath.indexOf('/share/CACHEDEV') === 0) return dbPath;
    var m = dbPath.match(/^\/share\/([^\/]+)(\/.*)?$/);
    if (!m) return dbPath;
    for (var i = 1; i <= 8; i++) {
      var cand = '/share/CACHEDEV' + i + '_DATA/' + m[1] + (m[2] || '');
      try { if (fs.existsSync(cand)) return cand; } catch (e) {}
    }
    return dbPath;
  }

  // 原文件的入库路径(/share/Xxx/...) -> 转换文件应存放的入库路径(不含后缀, 后面拼 _换壳.mp4 等)
  //   /share/Media/x/视频.ts -> /share/Media/转换/x/视频
  function convBase(dbPath, suffix) {
    var m = dbPath.match(/^(\/share\/[^\/]+)(\/.*)?\/([^\/]+)\.[A-Za-z0-9]{1,5}$/);
    if (!m) return null;
    var root = m[1], mid = m[2] || '', name = m[3];
    return root + '/转换' + mid + '/' + name + '_' + suffix + '.mp4';
  }

  // 提供静态访问: 各根目录下的 转换/ 子目录直接挂到 /convfiles/<根名>/转换/...
  // (用 express.static 逐个根挂载, 根目录本身在扫描时已经确定, 这里用中间件动态处理更省事)
  app.get('/convfiles/*', function (req, res) {
    try {
      var rel = decodeURIComponent(req.params[0]);      // 如 Media/转换/x/视频_换壳.mp4
      var dbPath = '/share/' + rel;
      var real = toRealPath(dbPath);
      if (!fs.existsSync(real)) return res.status(404).end();
      res.sendFile(real);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  var isMd5 = function (s) { return typeof s === 'string' && /^[0-9a-f]{32}$/i.test(s); };

  // 需要处理的判定(与前端 canPlay 的"仅换壳"/"要转码"逻辑对应, 交给 mode 区分):
  //   mode=remux     容器不认但编码认(ts/flv/avi-h264/mkv-h264/mkv-vp9 ...) -> ffmpeg -c copy
  //   mode=transcode 编码本身不认(mpeg4/wmv系/rv系等) -> NVENC 重新编码
  var OK_CODEC = ['h264', 'avc1', 'vp8', 'vp9', 'av1', 'av01', 'theora'];
  var OK_EXT   = ['mp4', 'm4v', 'webm', 'mov', 'ogv', 'ogg'];

  function classify(ext, codec) {
    var e = String(ext || '').toLowerCase();
    var c = String(codec || '').toLowerCase();
    if (OK_EXT.indexOf(e) >= 0 && OK_CODEC.indexOf(c) >= 0) return 'ok';
    if (['hevc', 'h265', 'hvc1'].indexOf(c) >= 0) return 'maybe';
    if (OK_CODEC.indexOf(c) >= 0) return 'remux';
    return 'transcode';
  }

  // GET /api/vconv/pending?mode=remux|transcode&limit=50
  // 返回每条视频的目标路径(convPath, 入库风格 /share/Xxx/转换/... ), PC 脚本直接用它算真实盘符路径
  app.get('/api/vconv/pending', function (req, res) {
    try {
      var db = getDb();
      var mode = req.query.mode === 'transcode' ? 'transcode' : 'remux';
      var suffix = mode === 'transcode' ? '转码' : '换壳';
      var limit = Math.min(500, Math.max(1, parseInt(req.query.limit || '50', 10) || 50));
      var rows = db.prepare(
        "SELECT md5, path, vcodec, size FROM photos " +
        "WHERE media_type='video' AND md5 IS NOT NULL AND web_ready = 0 AND vcodec IS NOT NULL " +
        "ORDER BY id"
      ).all();
      var out = [];
      for (var i = 0; i < rows.length && out.length < limit; i++) {
        var ext = (rows[i].path.match(/\.([A-Za-z0-9]{1,5})$/) || [])[1] || '';
        if (classify(ext, rows[i].vcodec) !== mode) continue;
        var cp = convBase(rows[i].path, suffix);
        if (!cp) continue;      // 路径不符合预期格式(极少见), 跳过不处理
        out.push({ md5: rows[i].md5, path: rows[i].path, vcodec: rows[i].vcodec,
                   size: rows[i].size, convPath: cp });
      }
      res.json({ videos: out, count: out.length });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // POST /api/vconv/done  {md5, mode}
  app.post('/api/vconv/done', express.json(), function (req, res) {
    var b = req.body || {};
    if (!isMd5(b.md5)) return res.status(400).json({ error: 'md5 无效' });
    try {
      getDb().prepare("UPDATE photos SET web_ready = ?, updated_at = strftime('%s','now') WHERE md5 = ?")
             .run(b.mode === 'transcode' ? 2 : 1, String(b.md5).toLowerCase());
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/api/vconv/done-batch', express.json({ limit: '2mb' }), function (req, res) {
    var items = (req.body && req.body.items) || [];
    if (!items.length) return res.status(400).json({ error: 'items 为空' });
    try {
      var db = getDb();
      var up = db.prepare("UPDATE photos SET web_ready = ?, updated_at = strftime('%s','now') WHERE md5 = ?");
      var n = 0;
      db.transaction(function (arr) {
        arr.forEach(function (it) {
          if (!isMd5(it.md5)) return;
          n += up.run(it.mode === 'transcode' ? 2 : 1, it.md5.toLowerCase()).changes;
        });
      })(items);
      res.json({ ok: true, updated: n });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // POST /api/vconv/fail  {md5, error}
  app.post('/api/vconv/fail', express.json(), function (req, res) {
    var b = req.body || {};
    if (!isMd5(b.md5)) return res.status(400).json({ error: 'md5 无效' });
    try {
      getDb().prepare("UPDATE photos SET web_ready = -1 WHERE md5 = ?").run(String(b.md5).toLowerCase());
      console.log('[vconv] 失败:', b.md5, b.error || '');
      res.json({ ok: true });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // GET /api/vconv/progress
  app.get('/api/vconv/progress', function (req, res) {
    try {
      var db = getDb();
      var rows = db.prepare(
        "SELECT path, vcodec, web_ready FROM photos WHERE media_type='video' AND vcodec IS NOT NULL"
      ).all();
      var remuxTotal = 0, remuxDone = 0, transTotal = 0, transDone = 0, failed = 0;
      rows.forEach(function (r) {
        var ext = (r.path.match(/\.([A-Za-z0-9]{1,5})$/) || [])[1] || '';
        var cls = classify(ext, r.vcodec);
        if (r.web_ready === -1) failed++;
        if (cls === 'remux') { remuxTotal++; if (r.web_ready > 0) remuxDone++; }
        if (cls === 'transcode') { transTotal++; if (r.web_ready > 0) transDone++; }
      });
      res.json({ remuxTotal: remuxTotal, remuxDone: remuxDone,
                 transTotal: transTotal, transDone: transDone, failed: failed });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  // POST /api/vconv/reset  {failedOnly:true}
  app.post('/api/vconv/reset', express.json(), function (req, res) {
    try {
      var sql = (req.body && req.body.failedOnly)
        ? "UPDATE photos SET web_ready = 0 WHERE web_ready = -1"
        : "UPDATE photos SET web_ready = 0 WHERE media_type='video'";
      var n = getDb().prepare(sql).run().changes;
      res.json({ ok: true, reset: n });
    } catch (e) { res.status(500).json({ error: e.message }); }
  });
};
