# video_transcode.ps1 -- re-encode old-codec videos for web playback (NVENC)
#
# For videos whose codec the browser cannot decode at all (mpeg4, wmv1/2/3, rv10/40,
# vc1, msmpeg4v3, flv1/vp6f, prores, mpeg1video ...). Unlike remux, this actually
# re-encodes video, so it is slow and uses the GPU. Original file is NEVER touched.
# Output path for each file is given by the NAS response (convPath), which mirrors
# the source directory under a subfolder next to the source root -- see
# video-conv.js convBase() on the server side.
#
# Uses NVIDIA NVENC (h264_nvenc). If your GPU/driver does not support it, the
# encoder probe at startup catches that before burning the whole queue on it.
#
# Run:
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\video_transcode.ps1
#   .\video_transcode.ps1 -Limit 20          (small test batch first -- do this)
#   .\video_transcode.ps1 -Jobs 2            (NVENC concurrent session limit on
#                                              consumer cards is often 2-3, start low)
#
# NOTE: pure ASCII on purpose. Windows PowerShell 5.1 reads BOM-less UTF-8
#       scripts as ANSI (GBK on Chinese systems), which mangles non-ASCII
#       characters and can break string terminators. Do not add non-ASCII
#       text (including Chinese) directly into this script file.

param(
    [string]$Nas     = 'http://192.168.0.3:3050',
    [int]$Limit      = 0,
    [int]$Jobs       = 2,        # NVENC concurrent session limit on consumer cards, keep low
    [string]$Quality = '23',     # CQ value for nvenc, lower = better quality, bigger file
    [string]$Preset  = 'p4'      # nvenc preset: p1(fastest/worst) .. p7(slowest/best)
)

$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Write-Host "[STOP] ffmpeg not found in PATH"; exit 1
}

Write-Host "Probing NVENC encoder..."
$probe = & ffmpeg -hide_banner -loglevel error -f lavfi -i "color=black:s=64x64:d=0.1" `
                   -c:v h264_nvenc -f null - 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "[STOP] h264_nvenc probe failed. GPU/driver may not support NVENC, or ffmpeg build lacks it."
    Write-Host $probe
    exit 1
}
Write-Host "NVENC OK"
Write-Host ""
Write-Host "NAS     : $Nas"
Write-Host "Jobs    : $Jobs   Quality(cq): $Quality   Preset: $Preset"
Write-Host "Output  : path given per-file by the NAS (mirrors source dir under a subfolder)"
Write-Host "NOTE: this re-encodes video -- slow, GPU-bound. Recommend -Limit 20 first."
Write-Host ""

$workerCode = {
    param($md5, $vpath, $convPath, $Quality, $Preset)

    $MAP = @(
        @('/share/Person',    'P:'),
        @('/share/Bak',       'B:'),
        @('/share/BAK',       'B:'),
        @('/share/Media',     'M:'),
        @('/share/Container', 'X:')
    )
    function ToWin($p) {
        foreach ($m in $MAP) {
            if ($p.StartsWith($m[0])) { return $m[1] + ($p.Substring($m[0].Length) -replace '/', '\') }
        }
        return $p -replace '/', '\'
    }

    $src = ToWin $vpath
    $out = ToWin $convPath

    $res = [pscustomobject]@{ md5 = $md5; ok = $false; err = '' }
    if (-not (Test-Path -LiteralPath $src)) { $res.err = 'file not found'; return $res }

    $outDir = Split-Path -Parent $out
    if (-not (Test-Path -LiteralPath $outDir)) {
        try { New-Item -ItemType Directory -Path $outDir -Force | Out-Null } catch {}
    }

    try {
        & ffmpeg -hide_banner -loglevel error -y -i "$src" `
                 -c:v h264_nvenc -preset $Preset -cq $Quality `
                 -c:a aac -b:a 128k `
                 -movflags +faststart -- "$out" 2>$null
        if ((Test-Path -LiteralPath $out) -and (Get-Item -LiteralPath $out).Length -gt 0) {
            $res.ok = $true
        } else {
            $res.err = 'output empty (nvenc failed?)'
            Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue
        }
    } catch { $res.err = $_.Exception.Message }
    return $res
}

$pool = [RunspaceFactory]::CreateRunspacePool(1, $Jobs)
$pool.Open()

[int]$totalDone = 0
[int]$totalFail = 0
[int]$round = 0
$swAll = [Diagnostics.Stopwatch]::StartNew()

while ($true) {
    $round++
    $batch = 20
    if ($Limit -gt 0) {
        $left = $Limit - $totalDone - $totalFail
        if ($left -le 0) { break }
        if ($left -lt 20) { $batch = $left }
    }

    try {
        $resp = Invoke-RestMethod -Uri "$Nas/api/vconv/pending?mode=transcode&limit=$batch" -TimeoutSec 30
    } catch {
        Write-Host "[STOP] cannot reach NAS: $($_.Exception.Message)"; break
    }
    $vids = @($resp.videos)
    if ($vids.Count -eq 0) { Write-Host "queue empty"; break }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $running = @()
    foreach ($v in $vids) {
        $ps = [PowerShell]::Create()
        $ps.RunspacePool = $pool
        $null = $ps.AddScript($workerCode).AddArgument($v.md5).AddArgument($v.path).
                    AddArgument($v.convPath).AddArgument($Quality).AddArgument($Preset)
        $running += [pscustomobject]@{ ps = $ps; handle = $ps.BeginInvoke() }
    }

    $results = @()
    foreach ($r in $running) {
        try { $out = $r.ps.EndInvoke($r.handle); if ($out) { $results += @($out) } }
        catch { Write-Host "  [WARN] worker error: $($_.Exception.Message)" }
        $r.ps.Dispose()
    }

    $good = @($results | Where-Object { $_.ok })
    $bad  = @($results | Where-Object { -not $_.ok })

    if ($good.Count -gt 0) {
        $items = @($good | ForEach-Object { @{ md5 = $_.md5; mode = 'transcode' } })
        $body = @{ items = $items } | ConvertTo-Json -Depth 5 -Compress
        try {
            Invoke-RestMethod -Uri "$Nas/api/vconv/done-batch" -Method Post -Body $body -ContentType 'application/json' -TimeoutSec 60 | Out-Null
        } catch { Write-Host "[WARN] done-batch failed: $($_.Exception.Message)" }
    }
    foreach ($b in $bad) {
        $fb = @{ md5 = $b.md5; error = $b.err } | ConvertTo-Json -Compress
        try { Invoke-RestMethod -Uri "$Nas/api/vconv/fail" -Method Post -Body $fb -ContentType 'application/json' -TimeoutSec 20 | Out-Null } catch {}
        Write-Host ("  FAIL {0}  {1}" -f $b.md5, $b.err)
    }

    $totalDone = $totalDone + $good.Count
    $totalFail = $totalFail + $bad.Count
    $sw.Stop()
    $secs = [Math]::Max(0.001, $sw.Elapsed.TotalSeconds)
    Write-Host ("round {0}: ok {1}, fail {2}, {3}s ({4}/s)  --  total ok {5} fail {6}" -f `
        $round, $good.Count, $bad.Count, [Math]::Round($secs), [Math]::Round($results.Count / $secs, 2), $totalDone, $totalFail)

    if ($Limit -gt 0 -and ($totalDone + $totalFail) -ge $Limit) { break }
}

$pool.Close()
$pool.Dispose()
$swAll.Stop()
Write-Host ""
Write-Host ("DONE: ok {0}, fail {1}, elapsed {2} min" -f $totalDone, $totalFail, [Math]::Round($swAll.Elapsed.TotalMinutes, 1))
