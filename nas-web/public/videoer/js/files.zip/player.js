// player.js — 富功能网页播放器
//
// 特性: 进度条(缓冲显示 + 悬停缩略图预览) / 音量 / 倍速 / 全屏 / 网页全屏 / 画中画
//       逐帧步进 / A-B 循环 / 截图 / 滤镜(亮度对比度饱和度色相翻转旋转) / 记忆播放位置
//       上一个下一个 / 完整快捷键
//
// 缩略图预览条复用抽帧产物: /vthumbs/<md5前2位>/<md5>_NN.jpg

'use strict';

var VPlayer = (function () {

  // ── 可播性判定: 容器与编码必须同时满足 ──────────────
  var OK_EXT   = ['mp4', 'm4v', 'webm', 'mov', 'ogv', 'ogg'];
  var OK_CODEC = ['h264', 'avc1', 'vp8', 'vp9', 'av1', 'av01', 'theora', ''];
  var MAYBE_CODEC = ['hevc', 'h265', 'hvc1'];   // 取决于系统解码器

  function extOf(p) {
    var m = String(p || '').match(/\.([A-Za-z0-9]{1,5})$/);
    return m ? m[1].toLowerCase() : '';
  }

  // 返回 'yes' | 'maybe' | 'no'
  // web_ready>0 说明已转出可播版本(vconv/), 无论原始容器/编码如何都算 yes
  function canPlay(v) {
    if (!v || !v.path) return 'no';
    if (v.web_ready > 0) return 'yes';
    var e = extOf(v.path);
    if (OK_EXT.indexOf(e) < 0) return 'no';
    var c = String(v.vcodec || '').toLowerCase();
    if (MAYBE_CODEC.indexOf(c) >= 0) return 'maybe';
    if (OK_CODEC.indexOf(c) < 0) return 'no';
    return 'yes';
  }

  // 转换文件路径规则(与 video-conv.js convBase 一致):
  //   /share/Media/x/视频.ts -> /share/Media/转换/x/视频_换壳.mp4  (web_ready=1)
  //   /share/Person/a/老片.avi -> /share/Person/转换/a/老片_转码.mp4  (web_ready=2)
  function convUrl(v) {
    var m = String(v.path || '').match(/^(\/share\/[^\/]+)(\/.*)?\/([^\/]+)\.[A-Za-z0-9]{1,5}$/);
    if (!m) return null;
    var suffix = v.web_ready === 2 ? '\u8f6c\u7801' : '\u6362\u58f3';  // 转码 / 换壳
    var convPath = m[1] + '/\u8f6c\u6362' + (m[2] || '') + '/' + m[3] + '_' + suffix + '.mp4';
    return '/convfiles' + convPath.replace(/^\/share/, '');
  }

  // 播放地址: 有转好的版本优先用它, 否则用原文件
  function srcOf(v) {
    if (v && v.web_ready > 0) {
      var u = convUrl(v);
      if (u) return u;
    }
    return '/original' + (v ? v.path : '');
  }

  // ── 内部状态 ────────────────────────────────────────
  var el = null, video = null;
  var cur = null, list = [], idx = -1;
  var hideTimer = null, seeking = false;
  var abA = null, abB = null;
  var NEUTRAL = { bright: 100, contrast: 100, saturate: 100, hue: 0, sepia: 0, blur: 0, vignette: 0 };
  var filters = { bright: 100, contrast: 100, saturate: 100, hue: 0, sepia: 0, blur: 0, vignette: 0,
                  flipH: false, flipV: false, rotate: 0 };
  var fxPreset = 0, fxPower = 100;

  // 预设: 偏暖为主, 皮肤质感优先。数值是"满强度"下的目标值, 由 fxPower 按比例缩放
  var PRESETS = [
    { n: '原始',   bright:100, contrast:100, saturate:100, hue:  0, sepia: 0,  blur:0,   vignette: 0  },
    { n: '暖肤',   bright:106, contrast:112, saturate:125, hue: -8, sepia:12,  blur:0,   vignette:10  },
    { n: '蜜色',   bright:108, contrast:115, saturate:135, hue:-12, sepia:18,  blur:0,   vignette:25  },
    { n: '暧昧',   bright:102, contrast:118, saturate:120, hue:-14, sepia:15,  blur:0,   vignette:45  },
    { n: '湿润',   bright:104, contrast:125, saturate:140, hue: -5, sepia: 6,  blur:0,   vignette:20  },
    { n: '柔光',   bright:110, contrast: 95, saturate:118, hue: -6, sepia: 8,  blur:0.5, vignette:15  },
    { n: '电影',   bright: 98, contrast:122, saturate:108, hue:  0, sepia: 4,  blur:0,   vignette:50  },
    { n: '夜色',   bright: 92, contrast:130, saturate:125, hue:-10, sepia:10,  blur:0,   vignette:60  },
    { n: '胶片',   bright:104, contrast:118, saturate: 95, hue:  4, sepia:25,  blur:0,   vignette:40  },
    { n: '冷艳',   bright:102, contrast:114, saturate:115, hue: 12, sepia: 0,  blur:0,   vignette:30  },
    { n: '高对比', bright:100, contrast:145, saturate:130, hue:  0, sepia: 0,  blur:0,   vignette:20  },
    { n: '黑白',   bright:104, contrast:125, saturate:  0, hue:  0, sepia: 0,  blur:0,   vignette:35  }
  ];

  var IS_MOB = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);

  var SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];

  function cfg(k) {
    return (typeof VCfg !== 'undefined') ? VCfg.get(k) : null;
  }

  function $(id) { return document.getElementById(id); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(s) {
    s = Math.max(0, Math.floor(s || 0));
    var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return h ? (h + ':' + pad(m) + ':' + pad(x)) : (m + ':' + pad(x));
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function shotUrl(md5, n) {
    if (!md5 || md5.length < 2) return '';
    return '/vthumbs/' + md5.slice(0, 2) + '/' + md5 + '_' + (n < 10 ? '0' : '') + n + '.jpg';
  }

  // ── DOM ─────────────────────────────────────────────
  function build() {
    if (el) return el;
    el = document.createElement('div');
    el.id = 'vpl';
    el.innerHTML =
      '<div class="vpl-stage" id="vpl-stage">' +
        '<video id="vpl-video" playsinline preload="metadata"></video>' +
        '<div class="vpl-center" id="vpl-center"></div>' +
        '<div class="vpl-spin" id="vpl-spin"></div>' +
        '<div class="vpl-vig" id="vpl-vig"></div>' +
        '<div class="vpl-toast" id="vpl-toast"></div>' +
      '</div>' +
      '<div class="vpl-ui" id="vpl-ui">' +
        '<div class="vpl-top">' +
          '<div class="vpl-tw">' +
            '<div class="vpl-crumb" id="vpl-crumb"></div>' +
            '<div class="vpl-title" id="vpl-title"></div>' +
          '</div>' +
          '<span class="vpl-meta" id="vpl-meta"></span>' +
          '<span class="vpl-b" id="vpl-cfg" title="设置">&#9881;</span>' +
          '<span class="vpl-x" id="vpl-close">&#10005;</span>' +
        '</div>' +
        '<div class="vpl-bottom">' +
          '<div class="vpl-bar" id="vpl-bar">' +
            '<div class="vpl-buf" id="vpl-buf"></div>' +
            '<div class="vpl-ab" id="vpl-ab"></div>' +
            '<div class="vpl-played" id="vpl-played"><i></i></div>' +
            '<div class="vpl-preview" id="vpl-preview"><img id="vpl-pimg" alt=""><span id="vpl-ptime"></span></div>' +
          '</div>' +
          '<div class="vpl-ctrl">' +
            '<span class="vpl-b" id="vpl-prev" title="上一个 (P)">&#9198;</span>' +
            '<span class="vpl-b vpl-play" id="vpl-play" title="播放/暂停 (空格)">&#9654;</span>' +
            '<span class="vpl-b" id="vpl-next" title="下一个 (N)">&#9197;</span>' +
            '<span class="vpl-vol">' +
              '<span class="vpl-b" id="vpl-mute" title="静音 (M)">&#128266;</span>' +
              '<input type="range" id="vpl-volbar" min="0" max="100" value="100">' +
            '</span>' +
            '<span class="vpl-time" id="vpl-time">0:00 / 0:00</span>' +
            '<span class="vpl-spacer"></span>' +
            '<span class="vpl-b vpl-txt" id="vpl-ab-btn" title="A-B 循环 (I 设A / O 设B)">A-B</span>' +
            '<span class="vpl-b vpl-txt" id="vpl-speed" title="倍速">1x</span>' +
            '<span class="vpl-b" id="vpl-shot" title="截图 (S)">&#128247;</span>' +
            '<span class="vpl-b" id="vpl-fx" title="滤镜">&#127912;</span>' +
            '<span class="vpl-b" id="vpl-pip" title="画中画">&#128250;</span>' +
            '<span class="vpl-b" id="vpl-wide" title="网页全屏 (T)">&#9645;</span>' +
            '<span class="vpl-b" id="vpl-full" title="全屏 (F)">&#9974;</span>' +
          '</div>' +
        '</div>' +
        '<div class="vpl-menu" id="vpl-speedmenu"></div>' +
        '<div class="vpl-menu vpl-fx" id="vpl-fxmenu"></div>' +
      '</div>';
    document.body.appendChild(el);
    video = $('vpl-video');
    wire();
    return el;
  }

  // ── 事件 ────────────────────────────────────────────
  function wire() {
    $('vpl-close').onclick = close;
    $('vpl-cfg').onclick = function (e) { e.stopPropagation(); if (typeof VCfg !== 'undefined') VCfg.open(); };
    $('vpl-play').onclick  = toggle;
    $('vpl-prev').onclick  = function () { jump(-1); };
    $('vpl-next').onclick  = function () { jump(1); };
    $('vpl-mute').onclick  = function () { video.muted = !video.muted; syncVol(); };
    $('vpl-shot').onclick  = screenshot;
    $('vpl-pip').onclick   = pip;
    $('vpl-wide').onclick  = function () { el.classList.toggle('wide'); };
    $('vpl-full').onclick  = fullscreen;
    $('vpl-ab-btn').onclick = cycleAB;
    $('vpl-speed').onclick = function (e) { e.stopPropagation(); toggleMenu('vpl-speedmenu', speedMenu); };
    $('vpl-fx').onclick    = function (e) { e.stopPropagation(); toggleMenu('vpl-fxmenu', fxMenu); };

    $('vpl-stage').onclick = function (e) { if (e.target === video || e.target.id === 'vpl-stage') toggle(); };
    $('vpl-stage').ondblclick = function () { if (cfg('dblAction') === 'play') toggle(); else fullscreen(); };

    $('vpl-volbar').oninput = function () {
      video.volume = this.value / 100;
      video.muted = video.volume === 0;
      syncVol();
      try { localStorage.setItem('vplVol', String(video.volume)); } catch (e) {}
    };

    video.addEventListener('timeupdate', onTime);
    video.addEventListener('progress', drawBuf);
    video.addEventListener('play',  function () { $('vpl-play').innerHTML = '&#10074;&#10074;'; });
    video.addEventListener('pause', function () { $('vpl-play').innerHTML = '&#9654;'; });
    video.addEventListener('waiting', function () { $('vpl-spin').classList.add('on'); });
    video.addEventListener('playing', function () { $('vpl-spin').classList.remove('on'); });
    video.addEventListener('canplay', function () { $('vpl-spin').classList.remove('on'); });
    video.addEventListener('ended', function () { if (cfg('autoNext') !== false && idx >= 0 && idx < list.length - 1) jump(1); });
    video.addEventListener('error', onError);
    video.addEventListener('loadedmetadata', onMeta);

    var bar = $('vpl-bar');
    bar.addEventListener('mousemove', onBarHover);
    bar.addEventListener('mouseleave', function () { $('vpl-preview').classList.remove('on'); });
    bar.addEventListener('mousedown', function (e) { seeking = true; seekAt(e); });
    document.addEventListener('mousemove', function (e) { if (seeking) seekAt(e); });
    document.addEventListener('mouseup', function () { seeking = false; });

    el.addEventListener('mousemove', showUI);
    document.addEventListener('keydown', onKey);
    document.addEventListener('click', function () { hideMenus(); });
  }

  // ── 打开 / 关闭 ─────────────────────────────────────
  function open(v, all, i) {
    build();
    cur = v; list = all || [v]; idx = (typeof i === 'number') ? i : 0;
    el.classList.add('show');
    document.body.style.overflow = 'hidden';

    $('vpl-title').textContent = String(v.path || '').split('/').pop();
    renderCrumb(v.path);
    $('vpl-meta').textContent = [
      v.width && v.height ? (v.width + '×' + v.height) : '',
      v.vcodec || '',
      v.size ? (v.size / 1048576 > 1024
        ? (v.size / 1073741824).toFixed(1) + 'GB'
        : Math.round(v.size / 1048576) + 'MB') : ''
    ].filter(Boolean).join('  ·  ');

    loadFx();
    abA = abB = null; drawAB();
    var ds = cfg('defSpeed') || 1;
    video.playbackRate = ds;
    $('vpl-speed').textContent = ds + 'x';

    try {
      var vol = parseFloat(localStorage.getItem('vplVol'));
      if (isNaN(vol)) vol = (cfg('defVolume') !== null ? cfg('defVolume') : 100) / 100;
      video.volume = Math.max(0, Math.min(1, vol));
    } catch (e) {}
    syncVol();

    video.src = srcOf(v);
    video.load();
    $('vpl-spin').classList.add('on');
    video.play().catch(function () {});
    showUI();
  }

  // 所在目录的面包屑, 点任一层跳到该目录
  function renderCrumb(path) {
    var box = $('vpl-crumb');
    if (!box) return;
    var parts = String(path || '').split('/').filter(Boolean);
    parts.pop();                       // 去掉文件名
    var h = '', acc = '';
    parts.forEach(function (seg, i) {
      acc += '/' + seg;
      // /share 和 /share/Person 两层不可点(是根)
      var clickable = (i >= 2);
      h += (i ? '<i>/</i>' : '') +
           '<span class="' + (clickable ? 'cl' : '') + '"' +
           (clickable ? ' onclick="VPlayer.goDir(\'' + acc.replace(/'/g, "\\'") + '\')"' : '') +
           '>' + esc(seg) + '</span>';
    });
    box.innerHTML = h;
  }

  // 跳到目录: 关掉播放器并让列表页筛选到该目录
  function goDir(d) {
    close();
    if (typeof pickDir === 'function') pickDir(d);
    else if (typeof window.pickDir === 'function') window.pickDir(d);
  }

  function onMeta() {
    // 恢复上次播放位置(距离结尾 15 秒内的不恢复)
    try {
      var k = 'vplPos_' + cur.md5;
      var pos = parseFloat(localStorage.getItem(k));
      if (cfg('resumePlay') !== false && pos > 5 && video.duration && pos < video.duration - 15) {
        video.currentTime = pos;
        flash('已跳到上次位置 ' + fmt(pos));
      }
    } catch (e) {}
    drawBuf();
  }

  function onError() {
    $('vpl-spin').classList.remove('on');
    $('vpl-center').innerHTML =
      '<div class="vpl-err">浏览器无法播放此格式<br>' +
      '<small>' + esc(cur.vcodec || '未知编码') + ' · ' + esc(extOf(cur.path)) + '</small><br>' +
      '<button onclick="VPlayer.toPot()">用 PotPlayer 打开</button></div>';
  }

  function close() {
    savePos();
    try { video.pause(); } catch (e) {}
    video.removeAttribute('src');
    video.load();
    el.classList.remove('show', 'wide');
    document.body.style.overflow = '';
    $('vpl-center').innerHTML = '';
    if (document.fullscreenElement) { try { document.exitFullscreen(); } catch (e) {} }
  }

  function savePos() {
    if (!cur || !cur.md5 || !video.duration) return;
    try {
      var k = 'vplPos_' + cur.md5;
      if (video.currentTime > 5 && video.currentTime < video.duration - 15) {
        localStorage.setItem(k, String(Math.floor(video.currentTime)));
      } else localStorage.removeItem(k);
    } catch (e) {}
  }

  function jump(d) {
    savePos();
    var n = idx + d;
    if (n < 0 || n >= list.length) { flash(d > 0 ? '已是最后一个' : '已是第一个'); return; }
    // 跳过不可播的
    while (n >= 0 && n < list.length && canPlay(list[n]) === 'no') n += d;
    if (n < 0 || n >= list.length) { flash('没有更多可在线播放的'); return; }
    open(list[n], list, n);
  }

  // ── 进度条 ──────────────────────────────────────────
  function onTime() {
    if (!video.duration) return;
    if (abA !== null && abB !== null && video.currentTime >= abB) video.currentTime = abA;
    $('vpl-played').style.width = (video.currentTime / video.duration * 100) + '%';
    $('vpl-time').textContent = fmt(video.currentTime) + ' / ' + fmt(video.duration);
    if (Math.floor(video.currentTime) % 5 === 0) savePos();
  }

  function drawBuf() {
    if (!video.duration || !video.buffered.length) return;
    var e2 = video.buffered.end(video.buffered.length - 1);
    $('vpl-buf').style.width = (e2 / video.duration * 100) + '%';
  }

  function barPct(e) {
    var r = $('vpl-bar').getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
  }

  function seekAt(e) {
    if (!video.duration) return;
    video.currentTime = barPct(e) * video.duration;
  }

  function onBarHover(e) {
    if (!video.duration) return;
    var p = barPct(e);
    var pv = $('vpl-preview');
    var shots = parseInt(cur && cur.shots, 10) || 0;
    if (shots > 0 && cur.md5) {
      var n = Math.max(1, Math.min(shots, Math.round(p * shots) || 1));
      var img = $('vpl-pimg');
      var u = shotUrl(cur.md5, n);
      if (img.getAttribute('src') !== u) img.src = u;
      img.style.display = '';
      img.style.width = (cfg('previewWidth') || 168) + 'px';
    } else {
      $('vpl-pimg').style.display = 'none';
    }
    $('vpl-ptime').textContent = fmt(p * video.duration);
    var r = $('vpl-bar').getBoundingClientRect();
    pv.style.left = Math.max(60, Math.min(r.width - 60, e.clientX - r.left)) + 'px';
    pv.classList.add('on');
  }

  // ── A-B 循环 ────────────────────────────────────────
  function cycleAB() {
    if (abA === null) { abA = video.currentTime; flash('A 点 ' + fmt(abA)); }
    else if (abB === null) {
      abB = video.currentTime;
      if (abB <= abA) { var t = abA; abA = abB; abB = t; }
      flash('B 点 ' + fmt(abB) + ' · 循环中');
    } else { abA = abB = null; flash('已取消循环'); }
    drawAB();
  }

  function drawAB() {
    var d = $('vpl-ab');
    if (abA === null || abB === null || !video.duration) { d.style.display = 'none'; return; }
    d.style.display = '';
    d.style.left  = (abA / video.duration * 100) + '%';
    d.style.width = ((abB - abA) / video.duration * 100) + '%';
    $('vpl-ab-btn').classList.add('on');
  }

  // ── 菜单 ────────────────────────────────────────────
  function hideMenus() {
    if (!el) return;
    $('vpl-speedmenu').classList.remove('on');
    $('vpl-fxmenu').classList.remove('on');
  }

  function toggleMenu(id, render) {
    var m = $(id), was = m.classList.contains('on');
    hideMenus();
    if (was) return;
    render(m);
    m.classList.add('on');
  }

  function speedMenu(m) {
    m.innerHTML = SPEEDS.map(function (s) {
      return '<div class="vpl-mi' + (video.playbackRate === s ? ' on' : '') +
             '" onclick="VPlayer.setSpeed(' + s + ')">' + s + 'x</div>';
    }).join('');
  }

  function setSpeed(s) {
    video.playbackRate = s;
    $('vpl-speed').textContent = s + 'x';
    hideMenus();
    flash(s + 'x');
  }

  // ── 滤镜 ────────────────────────────────────────────
  function fxMenu(m) {
    var chips = PRESETS.map(function (p, i) {
      return '<span class="vpl-pc' + (fxPreset === i ? ' on' : '') +
             '" onclick="VPlayer.preset(' + i + ')">' + p.n + '</span>';
    }).join('');

    var row = function (label, key, min, max, step, unit) {
      return '<div class="vpl-fxr"><label>' + label + '</label>' +
             '<input type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + filters[key] + '" ' +
             'oninput="VPlayer.setFx(\'' + key + '\', this.value)">' +
             '<span id="fxv-' + key + '">' + filters[key] + (unit || '') + '</span></div>';
    };

    m.innerHTML =
      '<div class="vpl-fxt">预设</div>' +
      '<div class="vpl-pcs">' + chips + '</div>' +
      '<div class="vpl-fxr vpl-pw"><label>强度</label>' +
        '<input type="range" min="0" max="150" step="5" value="' + fxPower + '" ' +
        'oninput="VPlayer.setPower(this.value)">' +
        '<span id="fxv-power">' + fxPower + '%</span></div>' +
      '<div class="vpl-fxt">微调</div>' +
      row('亮度', 'bright', 20, 200, 1, '%') +
      row('对比', 'contrast', 20, 200, 1, '%') +
      row('饱和', 'saturate', 0, 300, 1, '%') +
      row('色相', 'hue', -60, 60, 1, '\u00B0') +
      row('暖色', 'sepia', 0, 60, 1, '%') +
      row('暗角', 'vignette', 0, 90, 1, '%') +
      (IS_MOB ? '' : row('柔化', 'blur', 0, 3, 0.1, 'px')) +
      '<div class="vpl-fxb">' +
        '<button onclick="VPlayer.flip(\'H\')">水平翻转</button>' +
        '<button onclick="VPlayer.flip(\'V\')">垂直翻转</button>' +
        '<button onclick="VPlayer.rot()">旋转90</button>' +
        '<button onclick="VPlayer.resetFx(1)">重置</button>' +
      '</div>';
  }

  // 选预设: 按当前强度插值
  function preset(i) {
    fxPreset = i;
    applyPreset();
    saveFx();
    var m = $('vpl-fxmenu');
    if (m && m.classList.contains('on')) fxMenu(m);
    flash(PRESETS[i].n);
  }

  function setPower(v) {
    fxPower = parseInt(v, 10);
    var s2 = $('fxv-power');
    if (s2) s2.textContent = fxPower + '%';
    applyPreset();
    saveFx();
    var m = $('vpl-fxmenu');
    if (m && m.classList.contains('on')) {
      // 只刷新滑块数值, 不重建整个菜单(避免拖动时被打断)
      ['bright','contrast','saturate','hue','sepia','vignette','blur'].forEach(function (k) {
        var sp = $('fxv-' + k);
        if (sp) sp.textContent = filters[k] + (k === 'hue' ? '\u00B0' : (k === 'blur' ? 'px' : '%'));
      });
    }
  }

  // 目标值 = 中性 + (预设 - 中性) * 强度
  function applyPreset() {
    var p = PRESETS[fxPreset] || PRESETS[0];
    var k = fxPower / 100;
    ['bright','contrast','saturate','hue','sepia','vignette','blur'].forEach(function (key) {
      var base = NEUTRAL[key], target = p[key];
      var val = base + (target - base) * k;
      filters[key] = (key === 'blur') ? Math.round(val * 10) / 10 : Math.round(val);
    });
    if (IS_MOB) filters.blur = 0;      // 手机上模糊很吃性能
    applyFx();
  }

  function setFx(k, v) {
    filters[k] = (k === 'blur') ? parseFloat(v) : parseInt(v, 10);
    var sp = $('fxv-' + k);
    if (sp) sp.textContent = filters[k] + (k === 'hue' ? '\u00B0' : (k === 'blur' ? 'px' : '%'));
    applyFx();
    saveFx();
  }

  function flip(d) { if (d === 'H') filters.flipH = !filters.flipH; else filters.flipV = !filters.flipV; applyFx(); }
  function rot() { filters.rotate = (filters.rotate + 90) % 360; applyFx(); }

  function resetFx(notify) {
    fxPreset = 0; fxPower = 100;
    filters = { bright:100, contrast:100, saturate:100, hue:0, sepia:0, blur:0, vignette:0,
                flipH:false, flipV:false, rotate:0 };
    applyFx();
    if (notify) {
      saveFx();
      var m = $('vpl-fxmenu');
      if (m && m.classList.contains('on')) fxMenu(m);
      flash('已重置');
    }
  }

  function applyFx() {
    if (!video) return;
    var f = [];
    f.push('brightness(' + filters.bright + '%)');
    f.push('contrast(' + filters.contrast + '%)');
    f.push('saturate(' + filters.saturate + '%)');
    if (filters.hue)   f.push('hue-rotate(' + filters.hue + 'deg)');
    if (filters.sepia) f.push('sepia(' + (filters.sepia / 100) + ')');
    if (filters.blur)  f.push('blur(' + filters.blur + 'px)');
    video.style.filter = f.join(' ');

    var t = [];
    if (filters.rotate) t.push('rotate(' + filters.rotate + 'deg)');
    t.push('scaleX(' + (filters.flipH ? -1 : 1) + ')');
    t.push('scaleY(' + (filters.flipV ? -1 : 1) + ')');
    video.style.transform = t.join(' ');

    var vg = $('vpl-vig');
    if (vg) vg.style.opacity = (filters.vignette / 100);
  }

  function saveFx() {
    try { localStorage.setItem('vplFx', JSON.stringify({ p: fxPreset, k: fxPower, f: filters })); } catch (e) {}
  }

  function loadFx() {
    try {
      var d = JSON.parse(localStorage.getItem('vplFx') || 'null');
      if (!d) return;
      fxPreset = d.p || 0;
      fxPower  = (typeof d.k === 'number') ? d.k : 100;
      if (d.f) for (var k in NEUTRAL) if (typeof d.f[k] === 'number') filters[k] = d.f[k];
      if (IS_MOB) filters.blur = 0;
      applyFx();
    } catch (e) {}
  }

  // ── 其它 ────────────────────────────────────────────
  function toggle() { if (video.paused) video.play().catch(function () {}); else video.pause(); }

  function syncVol() {
    $('vpl-volbar').value = Math.round((video.muted ? 0 : video.volume) * 100);
    $('vpl-mute').innerHTML = (video.muted || video.volume === 0) ? '&#128263;' : '&#128266;';
  }

  function fullscreen() {
    if (document.fullscreenElement) { document.exitFullscreen(); return; }
    (el.requestFullscreen ? el.requestFullscreen() : Promise.reject()).catch(function () {});
  }

  function pip() {
    if (!document.pictureInPictureEnabled) { flash('浏览器不支持画中画'); return; }
    if (document.pictureInPictureElement) document.exitPictureInPicture();
    else video.requestPictureInPicture().catch(function () { flash('画中画失败'); });
  }

  function screenshot() {
    try {
      var c = document.createElement('canvas');
      c.width = video.videoWidth; c.height = video.videoHeight;
      c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
      var a = document.createElement('a');
      a.download = String(cur.path).split('/').pop().replace(/\.[^.]+$/, '') + '_' + Math.floor(video.currentTime) + 's.png';
      a.href = c.toDataURL('image/png');
      a.click();
      flash('已截图');
    } catch (e) { flash('截图失败(可能是跨域限制)'); }
  }

  function toPot() {
    if (typeof toWinPath !== 'function') { flash('无法生成路径'); return; }
    var a = document.createElement('a');
    a.href = 'potplayer://' + encodeURIComponent(toWinPath(cur.path));
    a.style.display = 'none';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    flash('已调起 PotPlayer');
  }

  function flash(msg) {
    var t = $('vpl-toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(t._tm);
    t._tm = setTimeout(function () { t.classList.remove('on'); }, 1600);
  }

  function showUI() {
    el.classList.remove('idle');
    clearTimeout(hideTimer);
    hideTimer = setTimeout(function () { if (!video.paused) el.classList.add('idle'); }, cfg('uiHideDelay') || 2600);
  }

  // ── 快捷键 ──────────────────────────────────────────
  function onKey(e) {
    if (!el || !el.classList.contains('show')) return;
    var tag = (e.target && e.target.tagName) || '';
    if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
    var k = e.key, handled = true;
    switch (k) {
      case ' ': case 'k': toggle(); break;
      case 'ArrowRight': { var st = e.shiftKey ? (cfg('seekBigStep') || 30) : (cfg('seekStep') || 5); video.currentTime += st; flash('+' + st + 's'); break; }
      case 'ArrowLeft':  { var st2 = e.shiftKey ? (cfg('seekBigStep') || 30) : (cfg('seekStep') || 5); video.currentTime -= st2; flash('-' + st2 + 's'); break; }
      case 'ArrowUp':    video.volume = Math.min(1, video.volume + (cfg('volStep') || 10) / 100); video.muted = false; syncVol(); flash('音量 ' + Math.round(video.volume * 100)); break;
      case 'ArrowDown':  video.volume = Math.max(0, video.volume - (cfg('volStep') || 10) / 100); syncVol(); flash('音量 ' + Math.round(video.volume * 100)); break;
      case 'f': fullscreen(); break;
      case 't': el.classList.toggle('wide'); break;
      case 'm': video.muted = !video.muted; syncVol(); break;
      case 's': screenshot(); break;
      case 'i': abA = video.currentTime; abB = null; drawAB(); flash('A 点 ' + fmt(abA)); break;
      case 'o': if (abA !== null) { abB = video.currentTime; drawAB(); flash('B 点 ' + fmt(abB)); } break;
      case 'n': jump(1); break;
      case 'p': jump(-1); break;
      case ',': video.pause(); video.currentTime -= 1 / (cfg('frameStep') || 25); flash('上一帧'); break;
      case '.': video.pause(); video.currentTime += 1 / (cfg('frameStep') || 25); flash('下一帧'); break;
      case 'Escape': close(); break;
      default:
        if (k >= '0' && k <= '9' && video.duration) {
          video.currentTime = video.duration * parseInt(k, 10) / 10;
        } else handled = false;
    }
    if (handled) { e.preventDefault(); showUI(); }
  }

  return {
    open: open, close: close, canPlay: canPlay,
    setSpeed: setSpeed, setFx: setFx, flip: flip, rot: rot, resetFx: resetFx,
    preset: preset, setPower: setPower, goDir: goDir,
    toPot: toPot
  };
})();
